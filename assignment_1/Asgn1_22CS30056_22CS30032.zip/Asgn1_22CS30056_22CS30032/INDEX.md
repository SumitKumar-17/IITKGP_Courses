# Submission Layout

- `lua-5.5.0/` — the complete, buildable interpreter source, with every
  part's changes applied cumulatively (`make linux` in `src/`, then
  `./lua -v` should print `Lua 5.5.0`). Also holds the Part A driver
  files (`fullgc.c`/`incrementalgc.c`/`generationalgc.c`), Part B's
  verification driver (`sweeptest.c`), and the Lua-level verification
  scripts used throughout (`esctest.lua`, `arenatest.lua`, `rectest.lua`,
  `gentest.lua`, `corotest.lua`).
- `testbench.lua` — the provided workload, unmodified, used as-is by
  every part.
- `PartA/` — `PART_A_REPORT.pdf`/`.md` and `results/` (callgrind
  outputs, call-graph PNGs, annotated profiles, memcheck logs).
- `PartB/` — `PART_B_DIFF.patch` and `README.md` (the design note).
- `PartC/` — `PART_C1_DIFF.patch`/`PART_C1_DESIGN.md` and
  `PART_C2_DIFF.patch`/`PART_C2_DESIGN.md`.
- `PartD/` — `PART_D_REPORT.pdf`/`.md` and `results/` (every callgrind
  output, perf log, and `/usr/bin/time` log referenced in the report,
  plus the chart PNGs and the two scripts that produced them,
  `analyze.py`/`make_charts.py`).
Not included: compiled binaries/object files (rebuildable from the
source above); a scratch comparison build of the *unmodified*
Lua 5.5.0 tree that was used only to produce Part D.3's stock-vs-current
numbers (byte-identical to this repo's own pre-assignment git history
plus copies of the driver files already included here, so shipping it
again would only add size, not information); and `WORK.md`, a
step-by-step narrative of how this was built kept in the project repo
for our own reference — not a deliverable, so left out of this zip.
